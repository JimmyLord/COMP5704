#pragma once

double MyGetSystemTime();
void printfIntWithCommas(int n);
