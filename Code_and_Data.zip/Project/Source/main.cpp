int CUDAMain();

int main()
{
    return CUDAMain();
}
