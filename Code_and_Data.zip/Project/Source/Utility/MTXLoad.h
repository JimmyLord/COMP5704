#pragma once

#include "Types.h"

typedef void (ReportCountFunc)(uint32 numVerts, uint32 numEdges);
typedef void (NewEdgeFunc)(uint32 v1, uint32 v2);

int MTXLoad(const char* filename, ReportCountFunc* pReportCountFunc, NewEdgeFunc* pNewEdgeFunc);
