#include <stdio.h>
#include "MTXLoad.h"

#pragma warning(disable : 4996)

int MTXLoad(const char* filename, ReportCountFunc* pReportCountFunc, NewEdgeFunc* pNewEdgeFunc)
{
    FILE* pFile = fopen( filename, "rb" );
    if( pFile == nullptr )
    {
        printf( "ERROR: File not found." );
        return 1;
    }

    unsigned int numVerts;
    unsigned int numEdges;
    while( true )
    {
        char nextByte = fgetc( pFile );
        if( feof( pFile ) )
            break;

        // Skip comments.
        if( nextByte == '%' )
        {
            fscanf( pFile, "%*[^\n]\n" );
            continue;
        }

        fseek( pFile, -1, SEEK_CUR );

        //char temp[255];
        //fscanf( pFile, "%[^\n]\n", temp );
        int numFound = fscanf( pFile, "%*d %d %d", &numVerts, &numEdges );
        if( numFound != 2 )
        {
            printf( "ERROR: Invalid file format." );
            fclose( pFile );
            return 1;
        }

        pReportCountFunc( numVerts, numEdges );
        break;
    }

    while( true )
    {
        unsigned int index1;
        unsigned int index2;
        int numFound = fscanf( pFile, "%d %d%*[^\n]\n", &index1, &index2 );
        if( numFound > 0 )
        {
            // Found a vert. Insert it.
            pNewEdgeFunc( index1-1, index2-1 );
        }
        else
        {
            // Finished.
            break;
        }
    }

    fclose( pFile );
    return 0;
}
