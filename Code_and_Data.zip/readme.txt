Built with vs2019

Tested with: CUDA Toolkit 11.0
https://developer.nvidia.com/cuda-downloads

Data set and algorithms can be selected here:
    CUDAMain.cu inside the CUDAMain() method

Initial number of buckets per hash table can be selected here:
    In DynamicGraph.cuh - line 10
        static const int BucketsPerHashTable = 3;
