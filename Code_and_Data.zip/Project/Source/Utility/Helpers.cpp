#include <Windows.h>
#include "Helpers.h"
#include <stdio.h>

double MyGetSystemTime()
{
    unsigned __int64 freq;
    unsigned __int64 time;

    QueryPerformanceFrequency( (LARGE_INTEGER*)&freq );
    QueryPerformanceCounter( (LARGE_INTEGER*)&time );

    double timeseconds = (double)time / freq;

    return timeseconds;
}

void printfIntWithCommas(int n)
{
    if( n < 0 )
    {
        printf( "-" );
        printfIntWithCommas( -n );
        return;
    }

    if( n < 1000 )
    {
        printf( "%d", n );
        return;
    }

    printfIntWithCommas( n/1000 );
    printf( ",%03d", n%1000 );
}