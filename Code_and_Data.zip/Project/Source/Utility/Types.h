#pragma once

typedef unsigned int uint32;

struct edge
{
    uint32 v1;
    uint32 v2;
};
